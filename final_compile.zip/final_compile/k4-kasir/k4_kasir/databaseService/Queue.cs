﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace k4_kasir.databaseService {
  class Queue {
    public string id { get; set; }
    public int nomor { get; set; }
    public int jumlah { get; set; }
    public int status { get; set; }
    public string createdAt { get; set; }
  }
}
