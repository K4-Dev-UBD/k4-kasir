﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace k4_kasir {
  public class Barang {
    public string nama { get; set; }
    public string gambar { get; set; }
    public int harga { get; set; }
    public int stok { get; set; }
    public string kategori { get; set; }
  }
}
